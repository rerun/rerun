Specify a version number for the generated archive.
