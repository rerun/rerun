A pithy one-liner is best.
