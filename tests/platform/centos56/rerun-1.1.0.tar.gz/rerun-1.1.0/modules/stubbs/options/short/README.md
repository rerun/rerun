You can give an option a short (usuallly a single character)
alternative.
