Specify `true` and the option variable will be exported as an environment variable.

