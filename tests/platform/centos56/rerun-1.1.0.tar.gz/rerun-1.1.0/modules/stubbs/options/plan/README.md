Specify the test plan name. Often these match command names.
In reality, it is the name of the test plan file minus the `-test.sh`.
