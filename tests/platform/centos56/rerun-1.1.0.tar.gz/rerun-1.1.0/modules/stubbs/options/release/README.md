Specify the release number to the archive.
Currently, only used for RPM archives.
