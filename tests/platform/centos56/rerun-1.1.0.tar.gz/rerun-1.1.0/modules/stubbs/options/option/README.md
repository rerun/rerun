Specifies the command option name.
