The archive output format.
