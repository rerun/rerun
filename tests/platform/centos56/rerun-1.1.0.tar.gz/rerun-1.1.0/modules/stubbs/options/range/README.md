The allowed values for the option argument.
*This is experimental.*
