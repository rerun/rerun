Use a valid shell glob pattern to match modules by name.
A space separated list of names is also valid.

