Supply command options data to your test.
Data should be provided in the form of a simple profile syntax. Eg,

    OPTION_VARIABLE=value

Where `OPTION_VARIABLE` refers to the name of the variable representing an option value.

For example, the "freddy:dance" command takes a "--jumps <>" argument.
To supply an answer file to the command create a file similar to below:

    JUMPS=3


