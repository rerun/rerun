Use *stubbs:rm-command* to remove a command from a module.

Basic usage
-----------

Remove the ping command from the waitfor module:

    rerun stubbs:rm-command --module waitfor --command ping

Associated tests and options will also be removed.

